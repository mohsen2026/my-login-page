require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true
}));
app.use(express.json());

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('Terhubung ke MongoDB!'))
  .catch(err => console.error('Gagal terhubung ke MongoDB:', err));

app.use('/api/auth', authRoutes);

app.get('/', (req, res) => {
  res.json({ message: 'API berjalan dengan baik!' });
});

app.listen(PORT, () => {
  console.log(`Server berjalan di port ${PORT}`);
});
